# 공시 벡터 DB (2026-11-18, 한도윤)

`python -m src.rag.build_index`로 만든 Chroma 벡터 DB입니다. 이 파일을 풀면 **임베딩을 다시 하지 않고** RAG 검색·질의응답을 쓸 수 있습니다.
코드는 main의 `src/rag/build_index.py`(Day 5 PR) 기준입니다.

## 들어 있는 것
- `data/vectordb/` : Chroma DB (컬렉션 `disclosure_chunks`, 청크 2,191개)와 `manifest.json`
- 모델 `text-embedding-3-small`, 공시 101건(첨부 청크 351개 포함), 토큰 1,493,193개
- 청크 지문 `e6cfcfb7cb3b`, 만든 시각 2026-11-18T10:38:23

## 실행 방법
1. 최신 main을 받고 패키지를 설치합니다 (`langchain-chroma` 추가됨).
   ```bash
   git pull origin main
   pip install -r requirements.txt
   ```
2. 이 zip을 **프로젝트 루트(`mid_project/`)에 그대로 풉니다.** `mid_project/data/vectordb/manifest.json`이 있으면 됩니다.
   - 기존 `data/vectordb/`에 다른 DB가 있으면 먼저 지우고 풉니다.
   - `README_벡터DB.md`(이 파일)는 루트에 같이 풀리니 확인 후 지워도 됩니다 (git에 올리지 마세요).
3. 맞춰 봅니다 (API 호출 없음).
   ```bash
   python -m src.rag.build_index --dry-run
   ```
   출력의 `지문`이 `e6cfcfb7cb3b`이면 내 청크와 같은 청크로 만든 DB입니다. 다르면 DART zip v2(2026-11-18)로 `collect_attachments --extract` → `news_link --apply` → `chunking`을 먼저 실행합니다.
4. 검색해 봅니다 (질문 임베딩에 `OPENAI_API_KEY` 필요).
   ```bash
   python -m src.rag.build_index --query "SK하이닉스 2024년 3분기 HBM 매출 증가율"
   ```
   1위가 `SK하이닉스 | ... | 2024-10-24 | 3Q24_Earnings Presentation_KOR.pdf p.5`이면 정상입니다.

## 주의
- `python -m src.rag.build_index`(옵션 없이)는 **실행하지 마세요.** DB를 지우고 다시 임베딩합니다 (비용 발생, 결과가 조금 달라질 수 있음).
